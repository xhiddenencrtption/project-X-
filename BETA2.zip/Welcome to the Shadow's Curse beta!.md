Welcome to the Shadow's Curse beta!
Thank you for downloading and testing Shadow's Curse. As one of our selected beta testers, you play an important role in the development of the game.

To get started:

    Unzip the shadows-curse-beta.zip file.
    Double-click shadows-curse.exe to begin installing the game.
    Follow the on-screen prompts to complete installation.
    Click "Play" to launch the game.

As a thank you for participating in the beta, you will receive a free copy of the full game upon official release. Your feedback and bug reports are instrumental in polishing Shadow's Curse and ensuring it is the deepest magical adventure possible.

If you experience any issues, please email beta-support@shadowscurse.com or visit www.shadowscurse.com/beta-support.

Shadow's Curse is an action-packed adventure game where you play as the son of a powerful magic clan head who has been cursed with shadow magic. Stripped of your abilities, you embark on a quest to find a cure and uncover the dark secret behind your clan's magic. Explore a vast open world, confront enemies and challenging quests, and navigate complex relationships with a diverse cast of characters. With stunning visuals and immersive gameplay, Shadow's Curse is an epic journey of redemption you won't want to miss.

Thank you for your support of Shadow's Curse. Your participation as an early beta tester will be rewarded with an exclusive in-game title to show your status.

Please share your feedback and discuss the game on our social media:
www.facebook.com/shadowscursegame
www.twitter.com/shadowscursegame
NOTE: some of this social media links/emails are yet to be created,we advice to contact the head of beta project at:rtyui235678@proton.me

All the best,
The Shadow's Curse team