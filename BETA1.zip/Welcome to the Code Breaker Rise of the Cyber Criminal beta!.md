Welcome to the Code Breaker: Rise of the Cyber Criminal beta!
Thank you for downloading and testing Code Breaker: Rise of the Cyber Criminal. As one of our selected beta testers, you play an important role in the development of the game.

To get started:

    Unzip the code-breaker-beta.zip file.
    Double-click code-breaker.exe to begin installing the game.
    Follow the on-screen prompts to complete installation.
    Click "Play" to launch the game.

As a thank you for participating in the beta, you will receive a free copy of the full game upon official release. Your feedback and bug reports are instrumental in polishing Code Breaker: Rise of the Cyber Criminal and ensuring it is the deepest cybercrime experience possible.

If you experience any issues, please email beta-support@codebreakergame.com or visit www.codebreakergame.com/beta-support.

Code Breaker: Rise of the Cyber Criminal is an action-packed game that puts you in the shoes of a young hacker determined to build a cybercriminal empire. Starting from humble beginnings, you'll need to use your coding and hacking skills to break into secure networks, steal data, and pull off elaborate heists. Recruit a team of skilled hackers and upgrade their skills and gear to take on dangerous missions and stay ahead of the law. Uncover a dark conspiracy threatening the city as you rise to become the ultimate code breaker.

Thank you for your support of Code Breaker: Rise of the Cyber Criminal. Your participation as an early beta tester will be rewarded with an exclusive in-game title to show your status.

Please share your feedback and discuss the game on our social media:
www.facebook.com/codebreakergame
www.twitter.com/codebreakergame
NOTE: some of this social media links/emails are yet to be created,we advice to contact the head of beta project at:rtyui235678@proton.me

All the best,
The Code Breaker: Rise of the Cyber Criminal team