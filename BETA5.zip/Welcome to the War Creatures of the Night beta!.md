Welcome to the War: Creatures of the Night beta!
Thank you for downloading and testing War: Creatures of the Night. As one of our selected beta testers, you play an important role in the development of the game.

To get started:

    Unzip the war-creatures-beta.zip file.
    Double-click war-creatures.exe to begin installing the game.
    Follow the on-screen prompts to complete installation.
    Click "Play" to launch the game.

As a thank you for participating in the beta, you will receive a free copy of the full game upon official release. Your feedback and bug reports are instrumental in polishing War: Creatures of the Night and ensuring it is the deepest multiplayer supernatural experience possible.

If you experience any issues, please email beta-support@warcreatures.com or visit www.warcreatures.com/beta-support.

War: Creatures of the Night is a fast-paced action game set in a world where werewolves, vampires, and hunters battle for supremacy. Choose your side and unleash your supernatural powers or advanced weapons in intense multiplayer battles. With stunning graphics and a variety of game modes, War: Creatures of the Night is the ultimate supernatural showdown.

Thank you for your support of War: Creatures of the Night. Your participation as an early beta tester will be rewarded with an exclusive in-game title to show your status.

Please share your feedback and discuss the game on our social media:
www.facebook.com/warcreaturesgame
www.twitter.com/warcreatures
NOTE: some of this social media links/emails are yet to be created,we advice to contact the head of beta project at:rtyui235678@proton.me

All the best,
The War: Creatures of the Night team
