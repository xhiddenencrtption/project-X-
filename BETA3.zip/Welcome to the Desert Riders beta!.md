Welcome to the Desert Riders beta!
Thank you for downloading and testing Desert Riders: In Search of the Legendary Creatures. As one of our selected beta testers, you play an important role in the development of the game.

To get started:

    Unzip the desert-riders-beta.zip file.
    Double-click desert-riders.exe to begin installing the game.
    Follow the on-screen prompts to complete installation.
    Click "Play" to launch the game.

As a thank you for participating in the beta, you will receive a free copy of the full game upon official release. Your feedback and bug reports are instrumental in polishing Desert Riders: In Search of the Legendary Creatures and ensuring it is the deepest desert adventure possible.

If you experience any issues, please email beta-support@desertriders.com or visit www.desertriders.com/beta-support.

Desert Riders: In Search of the Legendary Creatures is an epic action-adventure game set in a dangerous desert wasteland. As a nomadic rider, you'll travel across the landscape to uncover the secrets behind a series of legendary creatures. Battling enemies and surviving the harsh environment will test your skills and wit as you get closer to the truth.

Thank you for your support of Desert Riders: In Search of the Legendary Creatures. Your participation as an early beta tester will be rewarded with an exclusive in-game title to show your status.

Please share your feedback and discuss the game on our social media:
www.facebook.com/desertridersgame
www.twitter.com/desertriders
NOTE: some of this social media links/emails are yet to be created,we advice to contact the head of beta project at:rtyui235678@proton.me

All the best,
The Desert Riders team