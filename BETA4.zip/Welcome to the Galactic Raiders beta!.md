Welcome to the Galactic Raiders beta!
Thank you for downloading and testing Galactic Raiders: Rise to Power. As one of our selected beta testers, you play an important role in the development of the game.

To get started:

    Unzip the galactic-raiders-beta.zip file.
    Double-click galactic-raiders.exe to begin installing the game.
    Follow the on-screen prompts to complete installation.
    Click "Play" to launch the game.

As a thank you for participating in the beta, you will receive a free copy of the full game upon official release. Your feedback and bug reports are instrumental in polishing Galactic Raiders: Rise to Power and ensuring it is the deepest space pirate adventure possible.

If you experience any issues, please email beta-support@galacticraiders.com or visit www.galacticraiders.com/beta-support.

Galactic Raiders: Rise to Power is a space pirate adventure like no other. As a ruthless pirate, you'll travel the galaxy, assembling a crew and taking on dangerous rivals to claim territory and rise in power. The choices you make will determine whether you become a legendary outlaw or fade into the void of space.

Thank you for your support of Galactic Raiders: Rise to Power. Be sure to wishlist the game on Steam to be notified as soon as it's available to purchase. Your participation as an early beta tester will be rewarded with an exclusive in-game title to show your status as a pioneer in this galactic journey.

Please share your feedback and discuss the game on our social media:
www.facebook.com/galacticraidersgame
www.twitter.com/galacticraiders
NOTE: some of this social media links/emails are yet to be created,we advice to contact the head of beta project at:rtyui235678@proton.me

All the best,
The Galactic Raiders team